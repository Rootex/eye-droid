/** Automatically generated file. DO NOT MODIFY */
package com.Server.camerapreview;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}